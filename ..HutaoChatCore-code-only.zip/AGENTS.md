# HutaoChatCore Agent Handoff

## 当前状态（2026-08-14 项目清理后）

- 项目主线：HeadCore（唯一认知主体）为核心、唯一内置人格 `hutao_v1`（胡桃）的多模态角色陪伴后端。当前公开形态是 FastAPI Core HTTP + Web Desk PWA（`app/static/web/studio`）+ OpenAI-Compatible 接口 + 文件语音识别 + 原生微信小程序（`miniprogram/`）。
- 已退役并从源码移除：QQ/微信 Bot（NapCat/OneBot/Hermes）、CosyVoice2 语音克隆训练、Bert-VITS2 TTS provider、Ollama 视觉（`app/vision`）、MySQL V1 后端入口、旧 Desk UI（`app/static/desk`）、旧架构手册与旧出版工具链、新闻渲染浏览器方案。完整清理清单与理由见 `logs/project-cleanup/2026-08-14/project-cleanup-report.md`。
- `app/storage/mysql_repository.py` 保留：它是 Database V2、PostgreSQL、auth、knowledge、persona_management 的共享 SQL 传输基类，不是独立可删除的"V1 后端"。
- 实测基线（2026-08-14，`python -m pytest tests -q -p no:cacheprovider`）：`814 passed, 2 skipped`。
- Git 现状：本地仓库历史只有 2 个提交且历史中曾含模型权重（.git 约 8.9 GB，含 LFS 5.85 GB）。上传 GitHub 必须按 README 的 code-only 导出流程从新仓库推送；旧仓库只保留在本机，绝不 push。
- 文档唯一编辑源：根目录 `HUTAOCHATCORE_COMPLETE_ARCHITECTURE_AND_ACCEPTANCE_MANUAL.md`（其 `docs/` 副本与根目录同步）。技术审计报告：`docs/HUTAOCHATCORE_TECHNICAL_REPORT.md`。产品路线：`docs/WEB_PRODUCT_ROADMAP.md`。
- 历史开发交接记录已归档到 `docs/history/agent-handoff-archive.md`（只读），不再追加；新交接只写在本文档"当前对话交接"一节。

## 关键约定

- 只使用唯一 Python 环境 `D:\Tool\Progrmming-Tool\anaconda\envs\new\python.exe`，不要创建或切换其他虚拟环境。
- `.env`、密钥、Token、账号一律不写入代码、文档、日志或 Git；模板只维护 `.env.example`。
- `data/models/`、`external/`、`model_training/`、`data/` 下的模型与训练资产是本地部署资产，不提交 Git、不放 LFS。仓库只上传框架与代码，模型按 README 的本地模型清单自行下载。
- 不进行未经确认的大范围重构；保持 diff 小而可审。
- 开发任何模块前先给出完整实现计划，等用户确认；完成后跑聚焦测试并在 `logs/...` 写 Markdown 报告。
- 每一步开发都必须同步记录到本文档与 `README.md`。
- 人格、记忆、对话、情感、智能体、多模态等模块开发前，先调研论文与成熟开源项目，并把来源与工程映射写进模块报告。
- C 盘/系统级变更（安装、写入、策略）是红线，必须先获得用户明确批准。
- 社交平台接入优先官方或低风险接口；不使用 Hook/注入方案，除非用户明确批准并确认风险。
- 关系、权限、安全与隐私行为必须尽量由本地代码实现，不能只靠 Prompt。
- 任何可能诱导自杀、自伤或死亡的输出必须在发送前拦截或替换。

## 常用命令

```powershell
cd D:\Programming-file\Graduation-Project\HutaoChatCore
& 'D:\Tool\Progrmming-Tool\anaconda\envs\new\python.exe' -m compileall -q app scripts tests
& 'D:\Tool\Progrmming-Tool\anaconda\envs\new\python.exe' -m pytest tests -q -p no:cacheprovider
node --test miniprogram/tests/api-client.test.js miniprogram/tests/session.test.js
cmd /c "启动控制中心.bat --check-only"
```

注意：不要在仓库根目录裸跑 `pytest`，它会收集 `external/GPT-SoVITS` 自带第三方测试。

## 当前对话交接

### 2026-08-14 项目清理与上传前整理

- 用户要求：上传仓库只保留项目框架与代码；模型只写下载清单；删除杂质与废案；精简 logs；重写 README（中英双语）；技术报告更详细；优化 AGENTS.md。
- 执行内容：
  - 删除根目录误存文件（浏览器 devtools 误存、验收截图、旧 .env 备份、QQ 启动器 exe 等）、缓存（tmp/、__pycache__、.playwright-cli、pip_cache、node_modules 链接等）。
  - 删除 QQ/微信 Bot 残留：`integrations/`（仅剩 .pyc）、启动器 bat 中的 Hermes 逻辑（改为 Core-only）、`build/qq_launcher/`、相关文档（`docs/hermes-weixin-setup.md`、`docs/qq-napcat-login-guide.md`、`docs/HEADCORE_MULTI_CLIENT_ARCHITECTURE.md`、`docs/GPT_SOVITS_HUTAO_DEPLOYMENT.md`、`docs/HutaoChatCore-project-overview.md` 等）；QQ/微信退休记录保留在 `docs/archive/`。
  - 删除 CosyVoice2 语音克隆训练工具与 legacy 测试：`scripts/evaluate_hutao_flow_checkpoints.py`、`audit_hutao_voice_quality.py`、`audit_hutao_transcriptions.py`、`auto_label_hutao_voice.py`、`build_hutao_consensus_dataset.py` 与 4 个 `test_hutao_*` 测试。
  - 删除 Bert-VITS2 provider：`app/voice_chat/bert_vits2_tts.py`、`EllieTtsProvider` 与全部 bert_vits2 分支/别名/测试；TTS 只剩 gpt_sovits 一条路由。
  - 删除旧 Desk UI（`app/static/desk/`）与 `app/vision/`（含 `VisionObservationAdapter`/`adapt_vision_result` 与对应测试）；摄像头工作台（`app/camera` + `app/workbench`）保留。二次清理又移除 `app/perception` 的 `normalize_vision_result`/`merge_vision_outputs` 与 `app/providers` 的 `VisionRequest`/`VisionProvider`/`ProviderCapability.VISION` 及 3 个对应测试。
  - 移除 MySQL V1 后端入口：`STORAGE_BACKEND=mysql` 工厂分支、`migrations/000-003`、`scripts/mysql_smoke.py` 与相关测试/文档；`mysql_repository.py` 保留为 V2/PostgreSQL 共享基类。
  - 删除旧架构手册（`docs/PROJECT_ARCHITECTURE_AND_OPERATIONS.*`）、旧手册出版工具链（`scripts/build_architecture_publication.py`、`build_architecture_docx.py`、`print_architecture_pdf.js`、`capture_manual_diagrams.js` 与 `tests/test_architecture_publication.py`）、`output/html` 与 `output/pdf` 旧产物、人格系统旧设计文档（`docs/persona/`、`docs/persona-design.md`、`docs/persona-research.md`）。
  - 移除新闻渲染浏览器方案：`WORLD_RENDERED_FETCH_ENABLED`、`render_fallback_allowed`、`WorldSourceKind.RENDERED_BROWSER` 及 `docs/world/NEWS_SOURCE_STRATEGY.md` 中相关表述。
  - 精简 `logs/`：10.5 MB/1182 文件 -> 4.5 MB/874 文件（保留报告与结果 JSON，删原始日志；`final-acceptance`、`test-runs`、`storage` 完整保留）。
  - 优化文档：AGENTS.md 拆分为本精简版 + `docs/history/agent-handoff-archive.md`；README.md 重写为中英双语；`docs/HUTAOCHATCORE_TECHNICAL_REPORT.md` 重写为更详细版本；权威手册中的过期引用（app/vision、static/desk、STORAGE_BACKEND=mysql、931 passed 等）已修正。
- 验证：`compileall` PASS；全量 `814 passed, 2 skipped`；控制中心页面测试、部署文件测试、来源清单测试全部通过。
- 未执行：未提交任何 Git 变更；未删除任何大件本地资产（`external/`、`data/models/`、`data/hutao_voice/`、`data/stickers/` 等按用户要求保留不动）；未执行真实外部服务验收。
