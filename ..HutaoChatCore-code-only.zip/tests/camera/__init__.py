"""Camera perception foundation tests."""
